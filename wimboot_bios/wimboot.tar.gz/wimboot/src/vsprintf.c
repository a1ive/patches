/*
 * Quick and dirty wrapper around iPXE's unmodified vsprintf.c
 *
 */

#include <stdint.h>
#include <string.h>
#include "wimboot.h"

#define FILE_LICENCE(x)

#include "ipxe/vsprintf.c"
